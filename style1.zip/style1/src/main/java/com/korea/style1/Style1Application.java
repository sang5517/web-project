package com.korea.style1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Style1Application {

	public static void main(String[] args) {
		SpringApplication.run(Style1Application.class, args);
	}

}
